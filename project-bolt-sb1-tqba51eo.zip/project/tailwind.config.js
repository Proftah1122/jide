/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#3D224E',
          light: '#9B6FA3',
        },
        secondary: {
          DEFAULT: '#BBA521',
          light: '#F2C14E',
        },
        background: {
          DEFAULT: '#F1E6D1',
          dark: '#2a1736',
        },
        accent: {
          DEFAULT: '#D1B29D',
          dark: '#333333',
        }
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
      },
    },
  },
  plugins: [],
};