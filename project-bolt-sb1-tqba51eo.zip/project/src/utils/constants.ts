// Centralized constants for the application
export const CONTACT = {
  PHONE: '234 813 9497 705',
  EMAIL: 'Homeward@uniprimeinnovations.com'
} as const;

export const ROUTES = {
  HOME: '#home',
  SERVICES: '#services',
  ABOUT: '#about',
  CONTACT: '#contact'
} as const;

export const COMPANY = {
  NAME: 'Uniprime Homeward',
  TAGLINE: 'Helping You Succeed in Nigeria-Wherever You Are',
  DESCRIPTION: 'Your trusted partner for navigating Nigeria\'s business landscape with confidence and ease.'
} as const;