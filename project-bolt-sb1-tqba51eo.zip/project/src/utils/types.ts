// Common TypeScript interfaces and types
export interface NavItem {
  href: string;
  label: string;
}

export interface Service {
  icon: JSX.Element;
  title: string;
  description: string;
}

export type ButtonVariant = 'primary' | 'secondary' | 'outline';
export type ButtonSize = 'sm' | 'md' | 'lg';