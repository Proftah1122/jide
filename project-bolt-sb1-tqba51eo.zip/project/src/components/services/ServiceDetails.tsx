import React from 'react';
import { ArrowLeft, Lightbulb, BarChart, ClipboardCheck, Eye, Shield } from 'lucide-react';
import { GlassmorphicCard } from '../common/GlassmorphicCard';
import { SectionTitle } from '../common/SectionTitle';
import { Button } from '../common/Button';

export const ServiceDetails = () => {
  const services = [
    {
      id: 'idea-analysis',
      icon: <Lightbulb className="w-12 h-12 text-secondary" />,
      title: "Idea Analysis",
      subtitle: "Turning Concepts into Viable Plans",
      description: "Bringing a business idea to life requires more than just a good concept—it demands expert evaluation and market alignment.",
      benefits: [
        "Business Concept Review: Comprehensive evaluation of your business idea",
        "Market-Fit Analysis: Matching your concept with current market needs",
        "Profitability Forecasts: Financial projections and expected returns"
      ]
    },
    {
      id: 'market-insights',
      icon: <BarChart className="w-12 h-12 text-secondary" />,
      title: "Market Insights",
      subtitle: "Unlocking Market Potential",
      description: "Understanding the Nigerian market is key to making sound investment decisions. Our market research team gathers and analyzes data on industry trends, competitive landscapes, and consumer behavior.",
      benefits: [
        "Comprehensive Market Research: Data-driven reports on market conditions",
        "Competitor Analysis: Detailed evaluation of industry players and their strategies",
        "Customer Profiling: Insights into target demographics and consumer preferences"
      ]
    },
    {
      id: 'feasibility',
      icon: <ClipboardCheck className="w-12 h-12 text-secondary" />,
      title: "Feasibility Assessments",
      subtitle: "Ensuring Project Success from Day One",
      description: "Launching a business or project without understanding its feasibility can lead to costly mistakes. Our experts conduct thorough technical, financial, and operational feasibility studies.",
      benefits: [
        "Cost-Benefit Analysis: Assessment of investment versus expected returns",
        "Financial Projections: Revenue forecasts and expense breakdowns",
        "Project Risk Evaluation: Identification of potential challenges and mitigation strategies"
      ]
    },
    {
      id: 'transparency',
      icon: <Eye className="w-12 h-12 text-secondary" />,
      title: "Project Transparency",
      subtitle: "Stay Informed, Stay In Control",
      description: "We believe that trust is built through transparency. From project inception to completion, we provide real-time updates and detailed progress reports.",
      benefits: [
        "Regular Project Updates: Consistent communication on project progress",
        "Progress Monitoring: Milestone tracking and timeline management",
        "Comprehensive Project Reports: Detailed summaries of each project phase"
      ]
    },
    {
      id: 'fraud-prevention',
      icon: <Shield className="w-12 h-12 text-secondary" />,
      title: "Fraud Prevention",
      subtitle: "Your Security, Our Priority",
      description: "The fear of scams is a significant concern for Nigerians in the diaspora. We eliminate this risk by conducting extensive due diligence on all suppliers, vendors, and contractors.",
      benefits: [
        "Vendor Verification: Verification of all vendors before engagement",
        "Background Checks: In-depth screening of service providers",
        "Legal and Compliance Oversight: Assurance of contractual and regulatory adherence"
      ]
    }
  ];

  return (
    <div className="py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => window.history.back()}
            className="mb-8"
          >
            <ArrowLeft className="mr-2" size={16} />
            Back to Home
          </Button>
        </div>

        <SectionTitle>Our Services</SectionTitle>

        <div className="space-y-12">
          {services.map((service, index) => (
            <GlassmorphicCard key={service.id} className="transform hover:scale-[1.02]">
              <div className="flex flex-col md:flex-row gap-8">
                <div className="md:w-1/4 flex flex-col items-center md:items-start">
                  <div className="relative mb-4">
                    <div className="absolute inset-0 bg-secondary blur-xl opacity-20 rounded-full"></div>
                    {service.icon}
                  </div>
                  <h3 className="text-2xl font-bold text-secondary mb-2">{service.title}</h3>
                  <p className="text-secondary-light font-medium">{service.subtitle}</p>
                </div>
                <div className="md:w-3/4">
                  <p className="text-white/80 mb-6 leading-relaxed">{service.description}</p>
                  <h4 className="text-secondary font-semibold mb-4">What You Get:</h4>
                  <ul className="space-y-3">
                    {service.benefits.map((benefit, idx) => (
                      <li key={idx} className="flex items-start text-white/70">
                        <span className="w-2 h-2 mt-2 mr-3 bg-secondary rounded-full"></span>
                        {benefit}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </GlassmorphicCard>
          ))}
        </div>
      </div>
    </div>
  );
};