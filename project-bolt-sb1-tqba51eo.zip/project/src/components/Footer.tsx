import React from 'react';
import { Mail, Phone } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="bg-[#2a1736] text-white/80 py-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-[#bba521] font-semibold text-lg mb-4">Contact Us</h3>
            <div className="space-y-2">
              <p className="flex items-center">
                <Phone className="w-5 h-5 mr-2 text-[#bba521]" />
                234 813 9497 705
              </p>
              <p className="flex items-center">
                <Mail className="w-5 h-5 mr-2 text-[#bba521]" />
                Homeward@uniprimeinnovations.com
              </p>
            </div>
          </div>
          
          <div>
            <h3 className="text-[#bba521] font-semibold text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#about" className="hover:text-[#bba521] transition-colors">About Us</a></li>
              <li><a href="#services" className="hover:text-[#bba521] transition-colors">Services</a></li>
              <li><a href="#contact" className="hover:text-[#bba521] transition-colors">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-[#bba521] font-semibold text-lg mb-4">Newsletter</h3>
            <div className="flex">
              <input 
                type="email" 
                placeholder="Enter your email"
                className="bg-white/10 rounded-l-md px-4 py-2 focus:outline-none focus:ring-1 focus:ring-[#bba521] flex-1"
              />
              <button className="bg-[#bba521] text-[#3d224e] px-4 py-2 rounded-r-md font-medium
                               hover:bg-[#bba521]/90 transition-colors">
                Subscribe
              </button>
            </div>
          </div>
        </div>
        
        <div className="border-t border-white/10 mt-8 pt-8 text-center">
          <p>&copy; {new Date().getFullYear()} Uniprime Homeward. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};