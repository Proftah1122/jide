import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  variant?: 'glass' | 'solid';
}

export const Card = ({ children, className = '', variant = 'glass' }: CardProps) => {
  const variants = {
    glass: `backdrop-blur-md bg-[#F1E6D1]/10 border border-[#F1E6D1]/20 
           hover:border-[#BBA521]/30 shadow-lg hover:shadow-xl`,
    solid: `bg-[#F1E6D1] border border-[#D1B29D]`
  };

  return (
    <div className={`
      rounded-xl p-6 transition-all duration-300
      ${variants[variant]}
      ${className}
    `}>
      {children}
    </div>
  );
};