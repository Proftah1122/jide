import React from 'react';

interface GlassmorphicCardProps {
  children: React.ReactNode;
  className?: string;
}

export const GlassmorphicCard = ({ children, className = '' }: GlassmorphicCardProps) => {
  return (
    <div className={`backdrop-blur-md bg-white/5 p-8 rounded-xl
                    border border-white/10 hover:border-secondary/30
                    transition-all duration-300 ${className}`}>
      {children}
    </div>
  );
};