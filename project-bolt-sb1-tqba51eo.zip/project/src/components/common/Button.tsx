import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  children: React.ReactNode;
}

export const Button = ({ 
  variant = 'primary', 
  size = 'md', 
  children, 
  className = '',
  ...props 
}: ButtonProps) => {
  const baseStyles = 'rounded-full font-semibold transition-all duration-300 inline-flex items-center';
  
  const variants = {
    primary: 'bg-[#BBA521] text-[#3D224E] hover:bg-[#F2C14E] shadow-lg hover:shadow-xl',
    secondary: 'bg-[#9B6FA3] text-[#F1E6D1] hover:bg-[#3D224E]',
    outline: 'border-2 border-[#BBA521] text-[#BBA521] hover:bg-[#BBA521] hover:text-[#F1E6D1]'
  };

  const sizes = {
    sm: 'px-4 py-2 text-sm',
    md: 'px-6 py-3 text-base',
    lg: 'px-8 py-4 text-lg'
  };

  return (
    <button
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};