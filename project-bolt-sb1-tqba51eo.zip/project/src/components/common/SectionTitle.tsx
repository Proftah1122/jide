import React from 'react';

interface SectionTitleProps {
  children: React.ReactNode;
  className?: string;
}

export const SectionTitle = ({ children, className = '' }: SectionTitleProps) => {
  return (
    <h2 className={`text-3xl md:text-4xl font-bold text-center text-[#bba521] mb-12 ${className}`}>
      {children}
    </h2>
  );
};