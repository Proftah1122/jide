import React from 'react';
import { HeroSection } from './home/HeroSection';
import { ServicesSection } from './home/ServicesSection';
import { AboutSection } from './about/AboutSection';
import { MissionVisionSection } from './about/MissionVisionSection';

export const Home = () => {
  return (
    <main>
      <HeroSection />
      <ServicesSection />
      <AboutSection />
      <MissionVisionSection />
    </main>
  );
};