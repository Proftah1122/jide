import React from 'react';
import { Globe, Shield, Users, ArrowRight } from 'lucide-react';
import { SectionTitle } from '../common/SectionTitle';
import { GlassmorphicCard } from '../common/GlassmorphicCard';
import { Button } from '../common/Button';

export const ServicesSection = () => {
  const services = [
    {
      icon: <Globe className="w-8 h-8 text-secondary" />,
      title: "Market Insights",
      description: "Unlock deep market understanding with customized research and analysis."
    },
    {
      icon: <Shield className="w-8 h-8 text-secondary" />,
      title: "Fraud Prevention",
      description: "Protect your investment with our due diligence and risk mitigation services."
    },
    {
      icon: <Users className="w-8 h-8 text-secondary" />,
      title: "Project Management",
      description: "End-to-end project oversight from planning to successful completion."
    }
  ];

  return (
    <section className="py-20 px-4" id="services">
      <div className="max-w-7xl mx-auto">
        <SectionTitle>Our Services</SectionTitle>
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {services.map((service, index) => (
            <GlassmorphicCard key={index}>
              <div className="mb-4">{service.icon}</div>
              <h3 className="text-xl font-semibold text-secondary mb-2">
                {service.title}
              </h3>
              <p className="text-white/70">{service.description}</p>
            </GlassmorphicCard>
          ))}
        </div>
        
        <div className="text-center">
          <Button 
            variant="outline"
            onClick={() => window.location.href = '#/services'}
            className="group"
          >
            View All Services
            <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>
      </div>
    </section>
  );
};