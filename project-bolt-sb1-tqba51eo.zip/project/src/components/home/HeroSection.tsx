import React from 'react';
import { ArrowRight } from 'lucide-react';

export const HeroSection = () => (
  <section className="relative min-h-[90vh] flex items-center justify-center px-4">
    <div className="max-w-7xl mx-auto text-center">
      <h1 className="text-4xl md:text-6xl font-bold text-secondary mb-6
                     animate-text bg-gradient-to-r from-secondary via-secondary-light to-secondary 
                     bg-clip-text text-transparent">
        Helping You Succeed in Nigeria-Wherever You Are
      </h1>
      <p className="text-white/80 text-lg md:text-xl max-w-2xl mx-auto mb-8">
        Your trusted partner for navigating Nigeria's business landscape with confidence and ease.
      </p>
      <button className="bg-secondary text-primary px-8 py-3 rounded-full font-semibold
                         hover:bg-secondary-light transition-all duration-300
                         shadow-[0_0_15px_rgba(187,165,33,0.5)]
                         hover:shadow-[0_0_25px_rgba(187,165,33,0.7)]">
        Get Started
        <ArrowRight className="inline-block ml-2" size={20} />
      </button>
    </div>
    
    <div className="absolute bottom-0 left-0 w-full h-32 
                    bg-gradient-to-t from-primary to-transparent"></div>
  </section>
);