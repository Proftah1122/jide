import React from 'react';
import { Building } from 'lucide-react';
import { SectionTitle } from '../common/SectionTitle';
import { GlassmorphicCard } from '../common/GlassmorphicCard';

export const AboutSection = () => {
  return (
    <section className="py-20 px-4" id="about">
      <div className="max-w-7xl mx-auto">
        <SectionTitle>About Us</SectionTitle>
        
        <GlassmorphicCard className="mb-12">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="md:w-1/3">
              <div className="relative">
                <div className="absolute inset-0 bg-[#bba521] blur-2xl opacity-20 rounded-full"></div>
                <Building className="w-24 h-24 text-[#bba521] relative z-10 mx-auto" />
              </div>
            </div>
            <div className="md:w-2/3">
              <p className="text-white/80 leading-relaxed mb-4">
                Uniprime Homeward is a project management and business consultancy firm dedicated to helping 
                Nigerians in the diaspora achieve their goals back home. We specialize in providing market-specific 
                insights, feasibility assessments, project transparency, and fraud prevention services.
              </p>
              <p className="text-white/80 leading-relaxed">
                Through our trusted network of verified service providers, detailed project monitoring, and 
                personalized support, we ensure your ventures succeed without the usual headaches. With Uniprime 
                Homeward, you gain a reliable partner committed to making your investments safe, projects efficient, 
                and experiences stress-free.
              </p>
            </div>
          </div>
        </GlassmorphicCard>
      </div>
    </section>
  );
};