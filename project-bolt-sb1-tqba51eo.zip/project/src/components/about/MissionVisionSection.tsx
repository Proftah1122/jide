import React from 'react';
import { Target, Eye } from 'lucide-react';
import { GlassmorphicCard } from '../common/GlassmorphicCard';

export const MissionVisionSection = () => {
  return (
    <section className="py-20 px-4 bg-background-dark">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-8">
          <GlassmorphicCard>
            <div className="flex flex-col items-center text-center">
              <div className="relative mb-6">
                <div className="absolute inset-0 bg-secondary blur-xl opacity-20 rounded-full"></div>
                <Target className="w-16 h-16 text-secondary relative z-10" />
              </div>
              <h3 className="text-2xl font-bold text-secondary mb-4">Our Mission</h3>
              <p className="text-white/80 leading-relaxed">
                To empower Nigerians in the diaspora by delivering trusted, transparent, and 
                results-driven services that turn their projects and business ideas into 
                successful realities.
              </p>
            </div>
          </GlassmorphicCard>

          <GlassmorphicCard>
            <div className="flex flex-col items-center text-center">
              <div className="relative mb-6">
                <div className="absolute inset-0 bg-secondary blur-xl opacity-20 rounded-full"></div>
                <Eye className="w-16 h-16 text-secondary relative z-10" />
              </div>
              <h3 className="text-2xl font-bold text-secondary mb-4">Our Vision</h3>
              <p className="text-white/80 leading-relaxed">
                To be the leading consultancy service connecting Nigerians abroad with 
                sustainable and profitable business and project opportunities back home.
              </p>
            </div>
          </GlassmorphicCard>
        </div>
      </div>
    </section>
  );
};