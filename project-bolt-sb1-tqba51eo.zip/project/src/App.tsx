import React from 'react';
import { Home } from './components/Home';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ServiceDetails } from './components/services/ServiceDetails';

export const App = () => {
  const [currentPath, setCurrentPath] = React.useState(window.location.hash);

  React.useEffect(() => {
    const handleHashChange = () => setCurrentPath(window.location.hash);
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary to-background-dark">
      <div className="fixed top-0 left-0 w-full h-full pointer-events-none">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1550985543-49bee3167284')] opacity-5 bg-cover bg-center"></div>
      </div>
      <Navbar />
      {currentPath === '#/services' ? <ServiceDetails /> : <Home />}
      <Footer />
    </div>
  );
};

export default App;