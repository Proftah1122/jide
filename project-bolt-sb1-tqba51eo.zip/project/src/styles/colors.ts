// Color palette constants
export const colors = {
  background: '#F1E6D1',
  primary: {
    purple: '#3D224E',
    gold: '#BBA521',
  },
  secondary: {
    purple: '#9B6FA3',
    beige: '#D1B29D',
  },
  accent: {
    charcoal: '#333333',
    brightGold: '#F2C14E',
  },
} as const;